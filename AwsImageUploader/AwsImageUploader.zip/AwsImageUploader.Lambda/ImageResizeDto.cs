﻿namespace AwsImageUploader.Lambda
{
    public class ImageResizeDto
    {
        public string Resolution { get; set; }

        public string KeyName { get; set; }
    }
}
